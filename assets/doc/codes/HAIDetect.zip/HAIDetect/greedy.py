import os
import math
import copy
import matplotlib.pyplot as plt
import collections
import numpy as np
import random
from matplotlib import rc,rcParams
import sys
import pylab as pl




POP_COST = 1
LOC_COST = 1
MAX_INF_TIME = 200*24*60*60
infStates = [10,13,15,12,14]
locInfStates = [18, 19, 20]


#split_day_num = sys.argv[1]
split_day_num = 10
dirName = "data/train"+str(split_day_num)

#dirName = 'cascade'


    

def getAllPopulation(filename):
    pop = {}
    for line in open(filename):
        if(line[0] != '#'):
            vals = line.split()
            pop[vals[0].strip()] = True
    return pop
      
                                

def get_infection_days(dirName):
    cost = {}
    allSims = []
    for root, dirs, files in os.walk(dirName):
        for name in files:
            simulationFile = open(os.path.join(root, name))
            infection_dic = {} # key node, value dic [ no of infection)
            
            for line in simulationFile:
                
                if line[0].isdigit():
                    arr = line.strip().split()
                    node, day, infection = map(int, arr)
                    if infection in infStates or infection in locInfStates:
                        infection_dic[node] = infection_dic.get(node, 0)+1
                        if infection in infStates:
                            cost[node] = POP_COST 
                        elif infection in locInfStates:
                            cost[node] = LOC_COST
                        
            allSims.append(infection_dic)
            
    return [cost, allSims]




def compute_qual(sensor_dic, allSims):
    qual = 0
    for sim in allSims:
        curqual = 1
        for node, rate in sensor_dic.items():
            tau = sim.get(node,0)
            curqual = curqual*math.pow((1-rate),tau)
            #print(node, rate, tau)
        curqual = 1 - curqual
        qual += curqual
    return qual
                

def check_constraint(best,cost, budget):
    total = 0
    for key, val in best.items():
        total += val
    if total>= budget:
        return False
    else:
        return True

def GREEDY(budget):
    best = {}
    print(dirName)
    cost, data = get_infection_days(dirName)
    
    print(len(data))
    print(len(cost))

    #print(compute_qual({31101:1.0}, data))
    #print(31101 in cost.keys())

    possible_assignments = [ math.floor(number*10)/10 for number in pl.frange(0.5, 1.0, 0.5) ]
    print(possible_assignments)
    candidate_set = {}
    
    bestVal = None
    
    
    
    #print(31101 in candidate_set.keys())
    #while calc_cost(best, nodes_cost) < budget:
    seed_nodes = ['433860', '410458', '434151', '427168', '422965', '424363', '417511', '405510', '401522', '430225', '435927', '424950', '409386', '418027', '425476', '419519', '411730', '407609', '401552', '432584', '417356', '419472', '429581','434218', '427961', '420452' ]
    for node in seed_nodes:
        if int(node) in cost:
            del cost[int(node)]
            
    for node in cost.keys():
        candidate_set[node]= possible_assignments
        
    while check_constraint(best, cost, budget):
        bestVal = None
        oldBestScore = compute_qual(best, data)
        #print("oldbestscore", oldBestScore)
        
        max_normalized_gain = 0

        for node in candidate_set.keys():
            old_val = best.get(node,0)
            for assignment in candidate_set[node]:
                best[node]= assignment
                curScore = compute_qual(best, data)
                cur_normalized_gain = (curScore - oldBestScore)/assignment
                
                if(cur_normalized_gain > max_normalized_gain):
                    #print("here")
                    bestVal = (node, assignment)
                    max_normalized_gain = cur_normalized_gain
            best[node] = old_val
        
        print("bestval", bestVal)
        if bestVal[1]==1.0:
            new_range = []
        else:
            new_range = [ math.floor(number*10)/10 for number in pl.frange(bestVal[1], 1.0, 0.5) ]
        candidate_set[bestVal[0]] = new_range
        best[bestVal[0]] = bestVal[1]
        
    #print("****************")
    
    final_res = {}
    for node, assignment in best.items():
        if assignment > 0:
            final_res[node] = assignment
            
    #for node in final_res.keys():
        #print(node, final_res[node],cost[node])
        #print(data[1].get(node, 0))
        #print("***********************")
    #print(cost)
    
    
    res_file = open('res/DISCRETELATTICESensor'+str(split_day_num), 'w')
    res_file.write('sensor\trate\n')
    for node,val in final_res.items():
        res_file.write(str(node)+'\t'+str(val)+'\n')
    
    #best.append('433860')
    #return best
    #print(best)
    #plot(best, cost,  budget)
    #plot2(best)

def multi():
    sensors = []
    count = []
    for i in range(1,21):
        best = GREEDY(i)
        sensors.append(best)
        count.append(i)
        
    

def main():
    #multi()
    
    GREEDY(200)
    
if __name__ =='__main__':
    main()