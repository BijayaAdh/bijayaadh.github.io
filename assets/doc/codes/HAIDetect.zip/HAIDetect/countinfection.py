
import os
import sys

from collections import OrderedDict


infStates = [10,13,15,12,14]
locInfStates = [18, 19, 20]

split_day_num = sys.argv[1]
dirName = "data/train"+str(split_day_num)

def count_infections(dirName):
    count = {}
    
    for root, dirs, files in os.walk(dirName):
        for name in files:
            simulationFile = open(os.path.join(root, name))
            infection_dic = {} # key node, value dic [ no of infection)
            
            for line in simulationFile:
                
                if line[0].isdigit():
                    arr = line.strip().split()
                    node, day, infection = map(int, arr)
                    if infection in infStates or infection in locInfStates:
                        infection_dic[node] = infection_dic.get(node, 0)+1
            
            
            #print(infection_dic)
            for node, val in infection_dic.items():
                count[node] = count.get(node, 0)+1
            
    dd = OrderedDict(sorted(count.items(), key=lambda x: x[1]))
    
    seed_nodes = ['433860', '410458', '434151', '427168', '422965', '424363', '417511', '405510', '401522', '430225', '435927', '424950', '409386', '418027', '425476', '419519', '411730', '407609', '401552', '432584', '417356', '419472', '429581','434218', '427961', '420452' ]
    for node in seed_nodes:
        del dd[int(node)]
        
    return dd


print(count_infections(dirName))